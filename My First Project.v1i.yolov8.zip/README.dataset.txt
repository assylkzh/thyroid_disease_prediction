# My First Project > 2025-05-15 3:30am
https://universe.roboflow.com/thyroid-nodules-nliix/my-first-project-6dgnz

Provided by a Roboflow user
License: CC BY 4.0

